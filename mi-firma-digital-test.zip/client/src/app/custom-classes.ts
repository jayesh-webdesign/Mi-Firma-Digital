export class PurchaseCode {
    constructor(
        public purchasecode : string
      ) { }
}