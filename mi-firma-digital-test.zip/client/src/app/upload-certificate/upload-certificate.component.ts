import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'upload-certificate',
  templateUrl: './upload-certificate.component.html',
  styleUrls: ['./upload-certificate.component.scss']
})
export class UploadCertificateComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
