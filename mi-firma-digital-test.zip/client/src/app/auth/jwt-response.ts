export class JwtResponse {
    accessToken : string;
    type : string;
    p_code : string;
}