module.exports = {
    'secret' : 'super-secret-key'
}